<?php
//-------------------- AJUSTES MOODLE IES IMPAR --------------------------
ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
$i = 0; //DEGUB
$dsn = "pgsql:host=" . getenv("DB_REPLICATION_PEER2") . ";dbname=" . getenv("DB_NAME") . ";user=" . getenv("DB_USER") . ";password=" . getenv("DB_PASS");
echo "DSN: " . $dsn;
try{
  $conn = new PDO($dsn);
  $updateValue = array();
  $sequencias  = array();
  if($conn){
  	echo "<p style='color:green'>Conectado na base de dados <strong>MOODLE POLO</strong> com sucesso!<br></p>";
  	echo "<table>";
			echo" <tr>";
			echo" 	<th style='color:#ff5252'> --Tipo Sequencia--</th>";
			echo" 	<th style='color:#ea80fc'> --------- Nome da Sequencia ---------</th>";
			echo"   <th style='color:#ea80fc'> --------- Valor Atual da Sequencia ---------</th>";
			echo" 	<th style='color:#1976d2'> ---------- ID do Último Registro --------- </th>";
			echo" 	<th style='color:#009688'> ----------  Nova Sequencia  ----------</th>";
			echo" 	<th style='color:purple'>  Increment </th>";
			echo" 	<th style='color:#fb8c00'>Correcao Sequencia </th>";
			echo" </tr>";
			$sqlFinal = "";
			$sql = "SELECT * FROM information_schema.sequences";
            $res = $conn->query($sql);
			$conn->beginTransaction();
			foreach ( $res as $row) {
				echo" <tr>";
				if($row['sequence_name'] != "bdr_conflict_history_id_seq"){
					$seq = $row['sequence_name'];
				/*
					CONTROLE DOS ULTIMOS VALOR/INDICE DE CADA TABELA. SE FOR PAR, É NECESSÁRIO DEIXAR TODOS
					OS INDICES COMO PAR, O MESMO OCORRENDO CASO FOREM IMPAR
				*/
					$tableName = explode("_id_seq",$seq)[0];
					$sql2 = "SELECT last_value FROM ".$row['sequence_name'].";"; //BUSCANDO OS ULTIMOS INDICES DE CADA TABELA
					$result = $conn->query($sql2);
					$result = $result->fetchAll(PDO::FETCH_ASSOC);
					$lastVal = $result[0]['last_value'];
					$result = $conn->query("SELECT coalesce(max(id),0) as last_value FROM $tableName;");
	   			        $result = $result->fetchAll(PDO::FETCH_ASSOC);
	  			    	if(($result[0]['last_value'] % 3) == 0){ //DEIXANDO TUDO IMPAR, PARA O CASO MOODLE-POLO
	  			    		$val = $result[0]['last_value'] + 2;

				    	}else{
				    		$val = $result[0]['last_value'] + 2;
				    	}

				    	if(($result[0]['last_value'] % 2) == 0){
				    		$val = $result[0]['last_value'] + 1;
				    	}

				// // ----------------------------ALTERANDO O INCREMENTO DA SEQUENCIA PARA 2 ------------------------------------------------//
					$sql3 = "ALTER SEQUENCE ".$row['sequence_name']." INCREMENT BY 2;";
					#echo $sql3;
					$conn->exec($sql3);
#				 	$valor_correcao = $conn->query($sql3);
#				 	$valor_correcao = $valor_correcao->fetchAll(PDO::FETCH_ASSOC);
					$sqlFinal .= $sql3;



				// //----------------------------AJUSTANDO O VALOR DA SEQUENCIA   ------------------------------------------------//
					$sql4 = "SELECT setval('".$row['sequence_name']."',".$val.", true);";
					$conn->query($sql4);
#				 	$valor_correcao2 = $conn->query($sql4);
					$sqlFinal .= $sql4;


					echo"<td style='color:#ff5252'>". ++$i." - Impar</td><td style='color:#ea80fc'>".$row['sequence_name']."</td> <td style='color:#ff5252'> $lastVal </td> <td style='color:#1976d2'>".$result[0]['last_value']."</td><td style='color:#009688'>".$val."</td><td style='color:purple'>".$row['increment']."</td><td style='color:#fb8c00'>  SELECT setval('".$row['sequence_name']."',".$val.", true);</td>";
				// 	// $valor_correcao2 = $valor_correcao->fetchAll(PDO::FETCH_ASSOC);
			}
			echo" </tr>";
			}
		echo "</table>";
    		//$sqlFinal.="COMMIT TRANSACTION;
		$conn->commit();


  }
}catch (PDOException $e){
	// mesnagem de error
echo $e->getMessage();
}

?>
