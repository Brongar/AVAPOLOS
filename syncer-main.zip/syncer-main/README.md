# syncer

[![CI/CD](https://github.com/avapolo/syncer/actions/workflows/cicd.yaml/badge.svg)](https://github.com/avapolo/syncer/actions/workflows/cicd.yaml)

This service syncronizes moodle instances between servers.
