# Failure mitigation planning

If a export or import fails, the system should roll back to a state before the procedure was initiated.

This can be done by creating a backup volume from all of the affected systems, like the databases and moodle instance.
