
Two databases using bidirectional replication

MAIN DB -> main replica
SYNC DB -> syncronization replica

When in HEI (Higher Education Institution)

MAIN DB -> HEI DB
SYNC DB -> HEC DB

When in HEC (Higher Education Center)

MAIN DB -> HEC DB
SYNC DB -> HEI DB

Sync database is always off, except during initial installation and when importing data.
