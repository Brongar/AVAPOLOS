contents:

-\
 |- filedir/* -> moodledata filedir
 |- database/* -> main database (to be used as sync database on the other node)
 |- filedirList -> diff list for moodledata filedir (Not implmemented yet)

