# replication-bootstrapper

[![CI/CD](https://github.com/avapolo/replication-bootstrapper/actions/workflows/ci.yaml/badge.svg)](https://github.com/avapolo/replication-bootstrapper/actions/workflows/ci.yaml)

This service initializes bidirectional replication between two PostgreSQL 9.4 databases.
